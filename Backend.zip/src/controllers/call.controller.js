/**
 * Call controller — issues Agora RTC tokens so customer & staff can talk
 * in-app without exposing phone numbers. Only valid during the booking window.
 */
const asyncHandler = require('../utils/asyncHandler');
const ApiError = require('../utils/ApiError');
const sendResponse = require('../utils/ApiResponse');
const { buildRtcToken } = require('../config/agora');
const Booking = require('../models/Booking');
const Salon = require('../models/Salon');

// POST /calls/token   { bookingId }
exports.getToken = asyncHandler(async (req, res) => {
  const { bookingId } = req.body;
  const booking = await Booking.findById(bookingId);
  if (!booking) throw ApiError.notFound('Booking not found');

  const salon = await Salon.findById(booking.salon);
  const isCustomer = booking.customer.toString() === req.user._id.toString();
  const isOwner = salon && salon.owner.toString() === req.user._id.toString();
  if (!isCustomer && !isOwner && req.user.role !== 'staff' && req.user.role !== 'admin') {
    throw ApiError.forbidden('Not allowed');
  }
  if (!booking.communicationUnlocked) {
    throw ApiError.forbidden('Calls are available only after confirmation and before completion.');
  }

  // deterministic channel name per booking; numeric uid per user
  const channel = `booking_${booking._id}`;
  const uid = parseInt(req.user._id.toString().slice(-6), 16) % 1000000;
  const token = buildRtcToken(channel, uid, 'publisher', 3600);

  sendResponse(res, 200, 'Call token issued', token);
});
