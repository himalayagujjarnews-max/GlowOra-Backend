/**
 * Entry point — connects to DB/Redis, starts the HTTP + Socket.io server,
 * seeds the first admin, and handles graceful shutdown + crash safety.
 */
const http = require('http');
const app = require('./src/app');
const config = require('./src/config/env');
const connectDB = require('./src/config/db');
const { connectRedis } = require('./src/config/redis');
const { initSocket } = require('./src/socket');
const { startNotificationWorker } = require('./src/workers/notification.worker');
const seedAdmin = require('./src/utils/seedAdmin');
const seedData = require('./src/utils/seedData');
const scheduler = require('./src/services/scheduler.service');
const logger = require('./src/utils/logger');

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught Exception: ${err.message}`);
  process.exit(1);
});

async function start() {
  await connectDB();
  await connectRedis();
  await seedAdmin();
  await seedData();

  const server = http.createServer(app);
  await initSocket(server);      // attach Socket.io (+ Redis adapter if available)
  startNotificationWorker();     // consume the notification queue
  scheduler.start();             // background jobs: reminders, recurring bookings, expiry

  server.listen(config.port, () => {
    logger.info(`🚀 GlowOra API running in ${config.env} mode on port ${config.port}`);
    logger.info(`   Health: http://localhost:${config.port}/health`);
    logger.info(`   API:    http://localhost:${config.port}/api/v1`);
    logger.info(`   Socket: ws://localhost:${config.port}`);
  });

  process.on('unhandledRejection', (err) => {
    logger.error(`Unhandled Rejection: ${err.message}`);
    server.close(() => process.exit(1));
  });
  process.on('SIGTERM', () => {
    logger.info('SIGTERM received. Shutting down gracefully…');
    server.close(() => process.exit(0));
  });
}

start();
